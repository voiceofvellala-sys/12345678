<?php

/**
 * moderator
 * 
 * @package Sngine
 * @author Zamblek
 */

// initialize
$moderator_mode = true;

// fetch admin
require('admin.php');
